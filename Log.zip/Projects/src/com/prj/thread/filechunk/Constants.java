package com.prj.thread.filechunk;

public class Constants {
	
	public enum Constant{
		FILE_BUFFER_SIZE(2000000),
		THREAD_WAIT(1000),
		THREAD_SLEEP(10),
		MAX_THREAD_LIMIT(10000);
		
		int value;
		
		Constant(final int value){
			this.value = value;
		}

		public int getValue() {
			return value;
		}
		
	}

}
