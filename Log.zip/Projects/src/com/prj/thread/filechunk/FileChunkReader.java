package com.prj.thread.filechunk;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.concurrent.CountDownLatch;

public final class FileChunkReader implements Runnable {

	private int bufferSize;

	private CountDownLatch latch;

	private long offset;

	private RandomAccessFile inRandomAccessFile = null;

	private IFileOperations fileOperations = null;

	volatile long incrLength;

	volatile long fileSize;

	public FileChunkReader(String filename, int bufferSize, long fileSize, CountDownLatch latch,
			IFileOperations fileOperations) {
		this.bufferSize = bufferSize;
		this.fileSize = fileSize;
		this.fileOperations = fileOperations;
		this.latch = latch;
		try {
			inRandomAccessFile = new RandomAccessFile(filename, "rw");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		synchronized (this) {
			try {
				byte[] b = new byte[this.bufferSize];
				inRandomAccessFile.seek(offset);
				inRandomAccessFile.read(b, 0, this.bufferSize);
				this.fileOperations.readBytes(b);
				offset = offset + this.bufferSize;
				incrLength = incrLength + this.bufferSize;
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
			latch.countDown();
			if (inRandomAccessFile != null && latch.getCount() == 0) {
				try {
					inRandomAccessFile.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
