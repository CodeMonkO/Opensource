package com.prj.thread.filechunk;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws FileOperationException, IOException, InterruptedException {
		FileOperations f = new FileOperations();
		f.read("ChunkFile.txt");
	}

}
