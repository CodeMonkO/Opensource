package com.prj.thread.filechunk;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryType;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FileOperations implements IFileOperations {

	File file = new File("out.txt");

	File f = null;

	public void read(String fileName) throws FileOperationException, IOException, InterruptedException {
		f = new File(fileName);
		if (f.exists() && f.isFile()) {
			long length = f.length();
			long chunksCount = length / Constants.Constant.FILE_BUFFER_SIZE.getValue();
			CountDownLatch latch = new CountDownLatch((int) chunksCount);
			FileChunkReader fileReader = new FileChunkReader(fileName, Constants.Constant.FILE_BUFFER_SIZE.getValue(),
					length, latch, this);
			ExecutorService executor = Executors.newWorkStealingPool();
			System.out.println("Total Threads created " + chunksCount);
			long A = System.currentTimeMillis();
			long i = 0;
			// Number of Latches == Number of threads created
			while (latch.getCount() != 0) {
				// Max Threads that can be created
				if (i < Constants.Constant.MAX_THREAD_LIMIT.getValue()) {
					executor.submit(fileReader);
					i++;
				}
				for (MemoryPoolMXBean mpBean : ManagementFactory.getMemoryPoolMXBeans()) {
					if (mpBean.getType() == MemoryType.HEAP) {
						long threadMemory = mpBean.getUsage().getUsed();
						if (threadMemory > mpBean.getUsage().getCommitted() - 1) {
							System.out.println("Memory used by Threads " + threadMemory + " Max memory "
									+ mpBean.getUsage().getCommitted());
							System.gc();
							//Thread.sleep(1);
						}
					}
				}
			}
			try {
				latch.await();
				System.out.print("Completed in " + (System.currentTimeMillis() - A) / 1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void readBytes(byte[] chunks) {
		new Thread(new Runnable() {

			@Override
			public void run() {
				{
					PrintWriter out = null;
					if (file.exists() && !file.isDirectory()) {
						try {
							out = new PrintWriter(new FileOutputStream(new File("out.txt"), true));
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}
					} else {
						try {
							out = new PrintWriter("out.txt");
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}
					}
					if (out != null) {
						out.append(new String(chunks));
						out.close();
					}
				}

			}

		}).start();
	}
}
