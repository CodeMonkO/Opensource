package com.prj.thread.filechunk;

public interface IFileOperations {

	void readBytes(byte[] chunks);
}
