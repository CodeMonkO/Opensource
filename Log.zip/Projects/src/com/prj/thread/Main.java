package com.prj.thread;

import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {

	public static void main(String a[]) throws InterruptedException {
		Consumer<String> consumer = new Consumer<>();
		ExecutorService executorService = Executors.newCachedThreadPool();
		executorService.submit(consumer);
		Log<String> log = new Log<>();
		for (int i=0; i<8; i++) {
			log.d(String.valueOf(i));
		}
		Scanner sc = new Scanner(System.in);
		while(true) {
			log.d(sc.next());
		}
	}

}
