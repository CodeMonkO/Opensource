package com.prj.thread;

public final class LoggerQueue<T> {

	private Node<T> root = null;

	private Node<T> prev;

	private Node<T> front;

	private Node<T> rear;

	private int capacity;

	private static LoggerQueue<?> loggerQueue = null;

	private LoggerQueue() {
		super();
	}

	public static LoggerQueue<?> getInstance() {
		if (loggerQueue == null) {
			synchronized (LoggerQueue.class) {
				if (loggerQueue == null) {
					loggerQueue = new LoggerQueue<>(10);
				}
			}
		}
		return loggerQueue;
	}

	private LoggerQueue(final int capacity) {
		this.capacity = capacity;
		for (int i = 0; i < capacity; i++) {
			Node<T> node = new Node<T>();
			node.setIndex(i);
			if (root == null) {
				root = node;
				prev = node;
				front = node;
			} else {
				node.setPrev(prev);
				prev.setNext(node);
				prev = node;
				rear = node;
			}
		}
	}

	public void push(final T t) throws LoggerQueueException {
		synchronized (this) {
			while (front.getIndex() == capacity - 1 && front.getLog() != null) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			front.setLog(t);
			if (front.getNext() != null) {
				front = front.getNext();
			}
			notify();
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public T pop() {
		T t;
		synchronized (this) {
			while (rear.getIndex() == 0) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			t = rear.getLog();
			if (rear.getPrev() != null) {
				rear.setLog(null);
				rear = rear.getPrev();
			}			
			notify();
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return t;
	}

	public int getCapacity() {
		return capacity;
	}

}
