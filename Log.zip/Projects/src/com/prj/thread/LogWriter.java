package com.prj.thread;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

public class LogWriter<T> {

	public void write(T t) throws IOException {
		synchronized (this) {
			System.out.println(t);
			PrintWriter printWriter = new PrintWriter(new FileOutputStream(new File("Device1.log⁩"), true));
			printWriter.print(t);
			printWriter.printf("\n");
			printWriter.close();
		}
	}

}
