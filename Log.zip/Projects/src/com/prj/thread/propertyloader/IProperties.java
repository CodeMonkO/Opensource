package com.prj.thread.propertyloader;

import java.util.Properties;

public interface IProperties {

	void getProperties(Properties properties);
}
