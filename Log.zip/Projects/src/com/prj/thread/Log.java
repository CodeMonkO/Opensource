package com.prj.thread;

public class Log<T> implements Runnable {

	private LoggerQueue<T> logger = (LoggerQueue<T>) LoggerQueue.getInstance();

	private T t;

	public Log() {
		super();
	}
	public Log(T t) {
		this.t = t;
		try {
			Thread.sleep(7);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void d(T t) {
		try {
			logger.push(t);
		} catch (LoggerQueueException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		while (true) {
			try {
				if (t != null) {
					logger.push(t);
					t = null;
				}
			} catch (LoggerQueueException e) {
				e.printStackTrace();
			}
		}
	}
}
