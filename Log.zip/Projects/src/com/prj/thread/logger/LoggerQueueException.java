package com.prj.thread.logger;

public class LoggerQueueException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8807647975280319869L;
	
	public LoggerQueueException(String msg) {
		super(msg);
	}

}
